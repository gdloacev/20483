﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace Module10.Models
{
    [DataContract]
    class Picture
    {
        [DataMember]
        public int AlbumID { get; set; }
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public string Title { get; set; }
        [DataMember]
        public string Url { get; set; }
        [DataMember]
        public string ThumbnailUrl { get; set; }

        public Picture()
        {
        }

        public Picture(int albumID, int id, string title, string url, string thumbnailUrl)
        {
            AlbumID = albumID;
            Id = id;
            Title = title;
            Url = url;
            ThumbnailUrl = thumbnailUrl;
        }
    }
}
