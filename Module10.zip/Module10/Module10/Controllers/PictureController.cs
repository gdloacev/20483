﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Module10.Models;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using System.Threading.Tasks;
using System.Windows.Threading;

namespace Module10.Controllers
{
    class PictureController
    {
        private HttpWebRequest _request;
        private Uri _pictureUri;

        public async Task<List<Picture>> GetPictures() {
            return await Task.Run(() => GetRemotePictures("https://jsonplaceholder.typicode.com/photos"));
        }

        private List<Picture> GetRemotePictures(string url) {
            try
            {
                _pictureUri = new Uri(url);
                _request = WebRequest.Create(_pictureUri) as HttpWebRequest;
                _request.Method = "GET";

                var response = _request.GetResponse() as HttpWebResponse;

                if (response.ContentLength == 0)
                    return null;

                var stream = new StreamReader(response.GetResponseStream());
                var result = ReadJSON(stream.BaseStream);
                stream.Close();

                return result;
            }
            catch (Exception)
            {
                return null;
            }
        }

        private List<Picture> ReadJSON(Stream stream1)
        {

            StreamReader reader = new StreamReader(stream1);

            try
            {
                string json_str = reader.ReadToEnd();
                List<Picture> picture_list = JsonConvert.DeserializeObject<List<Picture>>(json_str);
                return picture_list;
            }
            catch (Exception)
            {
                return null;
            }
            finally
            {
                stream1.Close();
            }
        }
    }
}
