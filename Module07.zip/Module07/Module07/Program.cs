﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Module07.Models;
using System.IO;

namespace Module07
{
    public enum Status { InProcess, Completed }

    class Program
    {
        static bool running = true;
        public static List<Task> tasks = new List<Task>();
        static string option;
        static TaskDB taskDB = new TaskDB();

        static void Main(string[] args)
        {
            while (running)
            {
                Console.WriteLine("--------------------------");
                Console.WriteLine("+title -> Add Task");
                Console.WriteLine("-title -> Remove Task");
                Console.WriteLine("*title -> Complete Task");
                Console.WriteLine("'P' -> Print Tasks");
                Console.WriteLine("'Q' -> Quit");
                Console.WriteLine("--------------------------");
                option = Console.ReadLine();

                switch (option.ToUpper())
                {
                    case "Q":
                        running = false;
                        break;
                    case "P":
                        PrintTasks();
                        break;
                    default:
                        if (option.Contains("+"))
                        {
                            Console.WriteLine("N E W  T A S K");
                            Console.WriteLine("--------------------------------");
                            Console.Write("Description: ");
                            string desc = Console.ReadLine();
                            Console.Write("Due Date (YYYY-MM-DD): ");
                            DateTime duedate = DateTime.Parse(Console.ReadLine());

                            Task newTask = new Task(option.Replace("+", ""), desc, duedate, (int)Status.InProcess);
                            InsertTask(newTask);
                        }
                        else if (option.Contains("-"))
                        {
                            Task task = GetTask(option.Replace("-", ""));
                            RemoveTask(task);
                        }
                        else if (option.Contains("*"))
                        {
                            CompleteTask(option.Replace("*", ""));
                        }
                        else
                        {
                            Console.WriteLine("Invalid Option");
                        }
                        break;
                }
            }

            Console.WriteLine("Bye Bye!!");
        }

        public static void PrintTasks()
        {
            GetTasks();
            List<Task> task_ord = (from Task t in tasks orderby t.Title select t).ToList();

            Console.WriteLine(String.Format("{0,10}\t{1,10}\t{2,10}", "Title", "Due Date", "Status"));
            foreach (Task t in task_ord)
            {
                Console.WriteLine(String.Format("{0,10}\t{1,10}\t{2,10}", t.Title, t.DueDate.ToShortDateString(),
                    (t.Status == (int)Status.InProcess) ? "In Process" : "Completed"));
            }
        }

        public static void InsertTask(Task newTask)
        {
            tasks.Add(newTask);
            WriteDB(newTask);
        }

        public static void RemoveTask(Task task)
        {
            taskDB.Tasks.Remove(task);
            taskDB.SaveChanges();
        }

        public static Task GetTask(string title)
        {
            Task task = (from t in taskDB.Tasks where t.Title.Contains(title) select t).FirstOrDefault();
            return task;
        }

        public static void CompleteTask(string title)
        {
            Task task = GetTask(title);
            UpdateDB(task);
        }

        public static void GetTasks()
        {
            tasks.Clear();
            tasks = ReadDB();
        }

        public static void WriteDB(Task task)
        {
            try
            {
                Task oldTask = taskDB.Tasks.Find(task.Title);
                if (oldTask == null)
                {
                    taskDB.Tasks.Add(task);
                    taskDB.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void UpdateDB(Task task)
        {
            try
            {
                Task oldTask = taskDB.Tasks.Find(task.Title);
                if (oldTask != null)
                {
                    oldTask.Status = (int)Status.Completed;
                    taskDB.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }



        public static List<Task> ReadDB()
        {
            try
            {
                return taskDB.Tasks.ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }
    }
}
