﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;

namespace Module07.Models
{
    class TaskDB : DbContext
    {
        public TaskDB() : base("TaskDB") { }

        public DbSet<Task> Tasks { get; set; }
    }
}
