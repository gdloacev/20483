﻿using Module09.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Module09
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private TaskDB taskDB;
        private string owner;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            taskDB = new TaskDB();
            List<string> owner = (from t in taskDB.Tasks select t.Owner).ToList();
            var owners = owner.GroupBy(o => o).Select(grp => grp.First()).ToList();
            cmbOwner.DataContext = owners;
        }

        private void CmbOwner_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            owner = cmbOwner.SelectedItem as string;
            List<Task> tasks = (from t in taskDB.Tasks where t.Owner.Contains(owner) select t).ToList();
            lstTasks.DataContext = tasks;
        }

        private void SaveChanges() {
            try
            {
                taskDB.SaveChanges();
                CmbOwner_SelectionChanged(null, null);
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message,"Error saving changes");
            }
        }

        private void RemoveTask(Task task) {
            MessageBoxResult response = MessageBox.Show(
                String.Format("Remove {0}", task.Title),
                "Confirm",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question,
                MessageBoxResult.No);

            if (response == MessageBoxResult.Yes) {
                taskDB.Tasks.Remove(task);
                SaveChanges();
            }
        }

        private void AddTask() {
            TaskForm taskForm = new TaskForm();
            
            if (owner == null)
            {
                taskForm.Title = "New Task";
                taskForm.txtOwner.IsEnabled = true;
            }
            else {
                taskForm.Title = "New Task for " + owner;
                taskForm.txtOwner.IsEnabled = false;
            }

            if (taskForm.ShowDialog().Value) {
                Task newTask = new Task(
                    taskForm.txtTitle.Text,
                    (owner == null)? taskForm.txtOwner.Text : owner,
                    taskForm.txtDescription.Text,
                    DateTime.Parse(taskForm.dpDueDate.SelectedDate.ToString()),
                    (int)ConvertStatus(taskForm.chkStatus.IsChecked));

                taskDB.Tasks.Add(newTask);
                SaveChanges();
            }
        }

        private void EditTask(Task task) {
            TaskForm taskForm = new TaskForm();
            taskForm.Title = "Edit Task - " + task.Title;
            taskForm.txtOwner.IsEnabled = false;

            taskForm.txtTitle.Text = task.Title;
            taskForm.txtDescription.Text = task.Description;
            taskForm.dpDueDate.SelectedDate = task.DueDate;
            taskForm.chkStatus.IsChecked = (bool)ConvertStatus(task.Status);

            if (taskForm.ShowDialog().Value) {
                task.Title = taskForm.txtTitle.Text;
                task.Description = taskForm.txtDescription.Text;
                task.DueDate = DateTime.Parse(taskForm.dpDueDate.SelectedDate.ToString());
                task.Status = (int)ConvertStatus(taskForm.chkStatus.IsChecked);

                SaveChanges();
            }
        }

        private object ConvertStatus(object value) {
            switch (value.ToString()) {
                case "False":
                    return 0;
                case "True":
                    return 1;
                case "0":
                    return false;
                case "1":
                    return true;
                default:
                    return null;
            }
        }

        private void LstTasks_KeyDown(object sender, KeyEventArgs e)
        {
            Task task = lstTasks.SelectedItem as Task;
            switch (e.Key) {
                case Key.Delete:
                    RemoveTask(task);
                    break;
                case Key.Insert:
                    AddTask();
                    break;
                case Key.Enter:
                    EditTask(task);
                    break;
                default:
                    break;
            }
        }
    }

    class StatusConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value != null)
            {
                return (int)value == 0 ? "In Process" : "Completed";
            }
            else {
                return 0;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
