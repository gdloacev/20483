﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Module09.Models
{
    class Task
    {
        [Key]
        [Required]
        public string Title { get; set; }
        [Required]
        public string Owner { get; set; }
        [Required]
        public string Description { get; set; }
        [Required]
        public DateTime DueDate { get; set; }
        [Required]
        public int Status { get; set; }

        public Task()
        {
        }

        public Task(string title, string owner, string description, DateTime dueDate, int status)
        {
            Title = title;
            Owner = owner;
            Description = description;
            DueDate = dueDate;
            Status = status;
        }
    }
}
