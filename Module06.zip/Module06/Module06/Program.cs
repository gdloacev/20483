﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Module06.Models;
using Newtonsoft.Json;

namespace Module06
{
    public enum Status { InProcess, Completed }

    class Program
    {
        static bool running = true;
        public static List<Task> tasks = new List<Task>();
        static string option;

        static void Main(string[] args)
        {
            while (running)
            {
                Console.WriteLine("--------------------------");
                Console.WriteLine("+title -> Add Task");
                Console.WriteLine("-title -> Remove Task");
                Console.WriteLine("*title -> Complete Task");
                Console.WriteLine("'P' -> Print Tasks");
                Console.WriteLine("'Q' -> Quit");
                Console.WriteLine("--------------------------");
                option = Console.ReadLine();

                switch (option.ToUpper())
                {
                    case "Q":
                        running = false;
                        break;
                    case "P":
                        PrintTasks();
                        break;
                    default:
                        if (option.Contains("+"))
                        {
                            Console.WriteLine("N E W  T A S K");
                            Console.WriteLine("--------------------------------");
                            Console.Write("Description: ");
                            string desc = Console.ReadLine();
                            Console.Write("Due Date (YYYY-MM-DD): ");
                            DateTime duedate = DateTime.Parse(Console.ReadLine());

                            Task newTask = new Task(option.Replace("+", ""), desc, duedate, (int)Status.InProcess);
                            InsertTask(newTask);
                        }
                        else if (option.Contains("-"))
                        {
                            Task task = GetTask(option.Replace("-", ""));
                            RemoveTask(task);
                        }
                        else if (option.Contains("*"))
                        {
                            CompleteTask(option.Replace("*", ""));
                        }
                        else
                        {
                            Console.WriteLine("Invalid Option");
                        }
                        break;
                }
            }

            Console.WriteLine("Bye Bye!!");
        }

        public static void PrintTasks()
        {
            GetTasks();
            List<Task> task_ord = (from Task t in tasks orderby t.Title select t).ToList();

            Console.WriteLine(String.Format("{0,10}\t{1,10}\t{2,10}", "Title", "Due Date", "Status"));
            foreach (Task t in task_ord)
            {
                Console.WriteLine(String.Format("{0,10}\t{1,10}\t{2,10}", t.Title, t.DueDate.ToShortDateString(),
                    (t.Status == (int)Status.InProcess) ? "In Process" : "Completed"));
            }
        }

        public static void InsertTask(Task newTask)
        {
            tasks.Add(newTask);
            WriteJSON(tasks);
        }

        public static void RemoveTask(Task task)
        {
            tasks.Remove(task);
            WriteJSON(tasks);
        }

        public static Task GetTask(string title)
        {
            Task task = (from t in tasks where t.Title.Contains(title) select t).FirstOrDefault();
            return task;
        }

        public static void CompleteTask(string title)
        {
            Task task = GetTask(title);
            task.Status = (int)Status.Completed;
            WriteJSON(tasks);
        }

        public static void GetTasks() {
            tasks.Clear();
            tasks = ReadJSON();
        }

        public static void WriteJSON(List<Task> tasks) {

            FileStream stream1 = null;

            try
            {
                if (!Directory.Exists("./Files")) {
                    Directory.CreateDirectory("./Files");
                }

                stream1 = new FileStream("./Files/Tasks.json", FileMode.Create);
                StreamWriter writer = new StreamWriter(stream1);

                var json = JsonConvert.SerializeObject(tasks);
                writer.Write(json);
                writer.Flush();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally {
                stream1.Close();
            }
        }

        public static List<Task> ReadJSON(){

            if (!Directory.Exists("./Files"))
            {
                Directory.CreateDirectory("./Files");
            }

            FileStream stream1 = new FileStream("./Files/Tasks.json", FileMode.OpenOrCreate){Position = 0};
            StreamReader reader = new StreamReader(stream1);

            try
            {
                string json_str = reader.ReadToEnd();
                return JsonConvert.DeserializeObject<List<Task>>(json_str);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
            finally {
                stream1.Close();
            }
        }
    }
}
